class Person {
  constructor(name, age, gender) {
    this._name = name;
    this._age = age;
    this._gender = gender;
  }

  introduce() {
    return `Hello, my name is ${this._name}, I am a ${this._age} years old ${this._gender}.`;
  }
}

const person1 = new Person("John", 25, "male");
const person2 = new Person("Jane", 30, "female");

console.log(person1.introduce(), person2.introduce());
